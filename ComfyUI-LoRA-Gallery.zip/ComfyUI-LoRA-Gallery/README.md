# Lora Gallery Loaded Multi Model

Multi-model LoRA gallery for ComfyUI. Accepts up to 5 MODEL inputs and applies every active LoRA to every connected model slot.

## Installation

Extract this folder into `ComfyUI/custom_nodes/`:
```
ComfyUI/custom_nodes/ComfyUI-LoRA-Gallery/
├── __init__.py
├── README.md
├── lora_gallery_node.py
└── web/
    └── lora_gallery.js
```
Restart ComfyUI. The node appears as **Lora Gallery Loaded Multi Model** under the `loaders` category.

## How routing works

Every LoRA toggled "on" in the gallery is applied to every connected model slot. There is no family detection, no routing, no filtering. Sections are purely organizational — use them to sort your LoRAs visually, but the "on" toggle is what determines application.

This means: if you have a Qwen model connected to slot 1 and a Flux model connected to slot 2, and you have 3 LoRAs toggled on (two for Flux, one for Qwen), **every one will be attempted on both models**. LoRAs that don't match the target model's architecture will log shape-mismatch errors and skip silently; the run continues. You manage this by only toggling on the LoRAs relevant to each generation.

This is the same behavior as ComfyUI's built-in LoRA loaders: they don't care what you apply to what — the loader will try, and the sampler will show you whether it worked.

## Model-only

This node has no CLIP inputs or outputs. It uses ComfyUI's model-only LoRA loader so only the MODEL (UNet / DiT) side of LoRA deltas gets patched. For Flux, Qwen, and most modern character LoRAs this is the correct behavior.

## Slot reveal

Fresh node shows one MODEL input and one MODEL output. Connecting slot 1's model reveals slot 2. Same pattern through slot 5. Slots don't auto-collapse while connected.

## Diagnostics

Every execution prints a detailed log to the ComfyUI console:
- How many LoRAs are in the gallery vs how many are active
- For each connected slot, which LoRAs were applied, at what strength
- Any LoRA that failed to load, with the reason

If a character LoRA isn't affecting your output, check the console — it should show `APPLIED <lora_name> (strength=X)` for that LoRA on your target slot. If it says `FAILED` or doesn't appear at all, the log message tells you why.

## Toolbar

- **◧ Master List** — toggles the left inventory panel
- **★ Active** — filters master list to only show LoRAs you've selected
- **✏️ Edit Images** — click any tile to upload a preview image
- **⟳ Refresh Node** — reload LoRA list from disk
- **↺ Reset All LoRA Icon Images** — deletes every user-chosen preview image (confirmation required)
- **↺ Reset Node** — clears all in-node state (selections, sections, preview references)
